rm -rf Test_
ls
mkdir Test_
ls
cp a.out Test_
cp cmd.sh Test_
ls -al Test_
cd Test_
pwd
ls
cd ..
pwd
ls
